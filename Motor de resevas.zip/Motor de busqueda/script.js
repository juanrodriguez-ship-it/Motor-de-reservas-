let fechaIngresoSeleccionada = null;
let fechaSalidaSeleccionada = null;
let fechasOcupadas = [];
let cabanaSeleccionada = null;

const VALOR_POR_NOCHE = 350000; // 350.000 COP

const fechasInput = document.getElementById("fechas");
const fechaSalidaInput = document.getElementById("fechaSalida");
const nochesSpan = document.getElementById("noches");
const valorTotalSpan = document.getElementById("valorTotal");

// Flatpickr para fecha de ingreso (single, solo fechas futuras)
const flatpickrIngreso = flatpickr(fechasInput, {
  mode: "single",
  dateFormat: "Y-m-d",
  locale: "es",
  disable: [], // Se actualizará dinámicamente
  minDate: "today", // Deshabilita fechas pasadas
  onChange: function(selectedDates, dateStr, instance) {
    fechaIngresoSeleccionada = selectedDates[0] ? instance.formatDate(selectedDates[0], "Y-m-d") : null;
    calcularNoches();
    // Limitar fecha de salida
    if (selectedDates.length > 0) {
      fechaSalidaFlatpickr.set("minDate", selectedDates[0]);
    }
  },
  onDayCreate: function(dObj, dStr, fp, dayElem) {
    // Resalta los días ocupados
    const date = dayElem.dateObj;
    const formatted = fp.formatDate(date, "Y-m-d");
    if (fechasOcupadas.includes(formatted)) {
      dayElem.classList.add("flatpickr-day-ocupado");
      dayElem.setAttribute("title", "Ocupado");
    }
  }
});

// Flatpickr para fecha de salida (single)
const fechaSalidaFlatpickr = flatpickr(fechaSalidaInput, {
  mode: "single",
  dateFormat: "Y-m-d",
  locale: "es",
  disable: [],
  minDate: "today",
  onDayCreate: function(dObj, dStr, fp, dayElem) {
    const date = dayElem.dateObj;
    const formatted = fp.formatDate(date, "Y-m-d");
    if (fechasOcupadas.includes(formatted)) {
      dayElem.classList.add("flatpickr-day-ocupado");
      dayElem.setAttribute("title", "Ocupado");
    }
  },
  onChange: function(selectedDates, dateStr, instance) {
    fechaSalidaSeleccionada = selectedDates[0];
    calcularNoches();
  }
});

// Cálculo de noches y valor total
function calcularNoches() {
  if (!fechaSalidaSeleccionada || !fechaIngresoSeleccionada) {
    nochesSpan.textContent = "0";
    valorTotalSpan.textContent = "0";
    return;
  }
  // Crear objetos Date con horas específicas
  const fechaIngreso = new Date(fechaIngresoSeleccionada + "T15:00:00");
  const fechaSalida = new Date(flatpickrIngreso.formatDate(fechaSalidaSeleccionada, "Y-m-d") + "T14:00:00");
  const diffMs = fechaSalida - fechaIngreso;
  const diffDias = diffMs / (1000 * 60 * 60 * 24);
  const noches = Math.ceil(diffDias);
  nochesSpan.textContent = noches > 0 ? noches : "0";

  // Calcular el valor total por noche según día de la semana
  let valorTotal = 0;
  let fechaActual = new Date(fechaIngreso);
  for (let i = 0; i < noches; i++) {
    const diaSemana = fechaActual.getDay(); // 0=Dom, 1=Lun, ..., 6=Sab
    let precioNoche = 0;
    if (diaSemana >= 1 && diaSemana <= 4) { // Lunes a Jueves
      precioNoche = 280000;
    } else { // Viernes=5, Sábado=6, Domingo=0
      precioNoche = 350000;
    }
    valorTotal += precioNoche;
    // Avanza al siguiente día
    fechaActual.setDate(fechaActual.getDate() + 1);
  }

  valorTotalSpan.textContent = valorTotal > 0 ? valorTotal.toLocaleString("es-CO") : "0";
}

// Actualiza fechas deshabilitadas y resalta ocupados según la cabaña
async function actualizarDisponibilidad() {
  if (!cabanaSeleccionada) return;
  try {
    const res = await fetch(`/api/disponibilidad?cabana=${encodeURIComponent(cabanaSeleccionada)}`);
    fechasOcupadas = await res.json();
    flatpickrIngreso.set('disable', fechasOcupadas);
    fechaSalidaFlatpickr.set('disable', fechasOcupadas);

    // Refrescar el calendario para que onDayCreate se aplique
    flatpickrIngreso.redraw();
    fechaSalidaFlatpickr.redraw();

    // Limpiar selección si alguna ya no está disponible
    if (fechaIngresoSeleccionada && fechasOcupadas.includes(fechaIngresoSeleccionada)) {
      fechaIngresoSeleccionada = null;
      fechasInput._flatpickr.clear();
    }
    if (fechaSalidaSeleccionada && fechasOcupadas.includes(flatpickrIngreso.formatDate(fechaSalidaSeleccionada, "Y-m-d"))) {
      fechaSalidaSeleccionada = null;
      fechaSalidaInput._flatpickr.clear();
    }
    calcularNoches();
  } catch (e) {
    mostrarMensaje('Error consultando la disponibilidad.', true);
  }
}

// Manejar cambio de selección de cabaña
document.querySelectorAll('input[name="cabana"]').forEach(radio => {
  radio.addEventListener('change', function() {
    cabanaSeleccionada = this.value;
    actualizarDisponibilidad();
  });
});

document.getElementById('reservaForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const nombre = document.getElementById('nombre').value.trim();
  const apellido = document.getElementById('apellido').value.trim();
  const correo = document.getElementById('correo').value.trim();
  const telefono = document.getElementById('telefono').value.trim();
  const cabana = document.querySelector('input[name="cabana"]:checked');
  const noches = parseInt(nochesSpan.textContent, 10);
  const valorTotal = parseInt(valorTotalSpan.textContent.replace(/\./g, ''), 10);

  if (!nombre || !apellido || !correo || !telefono) {
    mostrarMensaje('Por favor, completa todos los campos.', true);
    return;
  }
  if (!fechaIngresoSeleccionada) {
    mostrarMensaje('Por favor, selecciona la fecha de ingreso.', true);
    return;
  }
  if (!fechaSalidaSeleccionada) {
    mostrarMensaje('Por favor, selecciona una fecha de salida.', true);
    return;
  }
  if (noches <= 0) {
    mostrarMensaje('La fecha de salida debe ser posterior a la de ingreso.', true);
    return;
  }
  if (!cabana) {
    mostrarMensaje('Por favor, selecciona una cabaña de interés.', true);
    return;
  }

  fetch('/api/reservas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      nombre,
      apellido,
      correo,
      telefono,
      fechaIngreso: fechaIngresoSeleccionada,
      fechaSalida: fechaSalidaSeleccionada ? fechaSalidaFlatpickr.formatDate(fechaSalidaSeleccionada, "Y-m-d") : null,
      noches,
      valorTotal,
      cabana: cabana.value
    })
  })
  .then(async res => {
    if (res.ok) {
      mostrarMensaje('¡Reserva realizada con éxito!');
      document.getElementById('reservaForm').reset();
      fechaIngresoSeleccionada = null;
      fechaSalidaSeleccionada = null;
      nochesSpan.textContent = "0";
      valorTotalSpan.textContent = "0";
      fechasInput._flatpickr.clear();
      fechaSalidaInput._flatpickr.clear();
      actualizarDisponibilidad();
    } else {
      const errorText = await res.text();
      mostrarMensaje('Error al guardar la reserva: ' + errorText, true);
    }
  })
  .catch(() => {
    mostrarMensaje('Error al conectar con el servidor.', true);
  });
});